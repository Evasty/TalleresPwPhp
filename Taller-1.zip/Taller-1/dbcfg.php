<?php
define('db_un', 'lain');
define('db_pwd', '48OAWAjszUKSehJn');
define('db_host', 'localhost');
define('db_name', 'fancydb');
